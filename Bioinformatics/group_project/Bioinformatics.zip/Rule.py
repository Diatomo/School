


class Rule:

	def __init__(self, gene1, value1, gene2=None, value2=None):
		self.gene1 = gene1
		self.val1 = value1
		self.gene2 = gene2
		self.val2 = value2
		self.patients = []


