

Author Charles Stevenson

to run the programs make sure text files:

          place_descriptions.txt
          rand_transitions.txt
          transitions.txt

are in the same directory as 
          
          QValueIteration.py
          ValueIteration.py

to run:

      python ValueIteration.py "place_descriptions.txt" "transitions.txt"

      python QValueIteration.py "place_descriptions.txt" "rand_transitions.txt"


