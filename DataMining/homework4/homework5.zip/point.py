
class Point(object):
    '''
        @Point
            data member object to contain point info
    '''
    def __init__(self,i,x,y,c):
        self.pointid = i
        self.x = x
        self.y = y
        self.c = c#c = class
