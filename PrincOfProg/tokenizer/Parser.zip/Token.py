


'''
    Dummy class at the moment to keep track of my tokens
'''


class Token(object):

    def __init__(self, token, lineNumber):
        self.__lineNum = lineNumber
        self.token = token
